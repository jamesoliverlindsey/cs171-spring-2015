#include <iostream>
using namespace std;

int main()
{
	cout << "Hello, World!\n";

		system("pause"); //lets the user terminate the program

	return 0;

} //ends program